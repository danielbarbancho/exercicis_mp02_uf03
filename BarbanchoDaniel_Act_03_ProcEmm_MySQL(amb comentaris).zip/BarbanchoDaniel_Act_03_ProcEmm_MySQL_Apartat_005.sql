// Part 1 fem el procediment.

USE videoclub;

DELIMITER //

DROP PROCEDURE IF EXISTS act05_agafaNomEdatActorPrincipal//

CREATE PROCEDURE act05_agafaNomEdatActorPrincipal(
IN codi_peli smallint)
BEGIN

// Part 2 fem les accions del procediment.

DECLARE codi_Actor smallint;
DECLARE nomActor varchar(30);
DECLARE edatActor smallint;

SELECT id_actor INTO codi_Actor
FROM ACTORS_PELLICULES
WHERE id_peli = codi_peli AND principal = 1;

SELECT nom_actor INTO @nomActor
FROM ACTORS
WHERE id_actor = codi_Actor;

SELECT (YEAR(CURDATE()) - anynaix_actor) INTO @edatActor
FROM ACTORS
WHERE id_actor = codi_Actor;

END //

// Part 3 fem funcionar el procediment.

DELIMITER ;

CALL act05_agafaNomEdatActorPrincipal(1);

SELECT @nomActor;

SELECT @edatActor;