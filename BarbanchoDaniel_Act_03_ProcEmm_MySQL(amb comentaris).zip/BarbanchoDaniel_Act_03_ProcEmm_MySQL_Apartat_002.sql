// Part 1 creiem el procediment.

USE videoclub;

DELIMITER //

DROP PROCEDURE IF EXISTS act02_agafaPeliAmbMesRecaptacio;

CREATE PROCEDURE act02_agafaPeliAmbMesRecaptacio()

// Part 2 fem les accions del procediment.

BEGIN

DECLARE codiPeli smallint unsigned;

SELECT id_peli INTO @codiPeli
FROM PELLICULES
WHERE recaudacio_peli = (SELECT MAX(recaudacio_peli) FROM PELLICULES);

END //

// Part 3 fem funcionar el procediment;

DELIMITER ;

CALL act02_agafaPeliAmbMesRecaptacio;

SELECT @codiPeli;