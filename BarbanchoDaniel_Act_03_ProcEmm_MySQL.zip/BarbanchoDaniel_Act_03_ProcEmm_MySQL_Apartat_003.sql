USE videoclub;



DELIMITER //

DROP PROCEDURE IF EXISTS act03_agafaNomPeliMesRecaptacio;

CREATE PROCEDURE act03_agafaNomPeliMesRecaptacio()

BEGIN

DECLARE nomPeli varchar (30);
DECLARE recaudPeli smallint;

SELECT titol_peli INTO @nomPeli
FROM PELLICULES
WHERE recaudacio_peli = (SELECT MAX(recaudacio_peli) FROM PELLICULES);

SELECT recaudacio_peli INTO @recaudPeli
FROM PELLICULES
WHERE recaudacio_peli = (SELECT MAX(recaudacio_peli) FROM PELLICULES);

END //

DELIMITER ;

CALL act03_agafaNomPeliMesRecaptacio;

SELECT @nomPeli;

SELECT @recaudPeli;