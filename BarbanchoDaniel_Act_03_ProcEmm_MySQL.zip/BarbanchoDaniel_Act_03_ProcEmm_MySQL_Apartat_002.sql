USE videoclub;

DELIMITER //

DROP PROCEDURE IF EXISTS act02_agafaPeliAmbMesRecaptacio;

CREATE PROCEDURE act02_agafaPeliAmbMesRecaptacio()

BEGIN

DECLARE codiPeli smallint unsigned;

SELECT id_peli INTO @codiPeli
FROM PELLICULES
WHERE recaudacio_peli = (SELECT MAX(recaudacio_peli) FROM PELLICULES);

END //

DELIMITER ;

CALL act02_agafaPeliAmbMesRecaptacio;

SELECT @codiPeli;