USE videoclub;

DELIMITER //

DROP PROCEDURE IF EXISTS act04_agafaActorPrincipal//

CREATE PROCEDURE act04_agafaActorPrincipal(
IN codi_peli smallint)
BEGIN

DECLARE codiActor smallint;

SELECT id_actor INTO @codiActor
FROM ACTORS_PELLICULES
WHERE id_peli = codi_peli AND principal = 1;

END //

DELIMITER ;

CALL act04_agafaActorPrincipal(1);

SELECT @codiActor;


